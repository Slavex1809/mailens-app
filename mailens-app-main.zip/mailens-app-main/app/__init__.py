"""
MailLens AI - Intelligent Email Classification System
"""

__version__ = "2.0.0"
__author__ = "MailLens AI Team"
__description__ = "Zero-shot email classification using Sentence Transformers"

# Экспорт основных компонентов
__all__ = [
    'email_processor',
    'classifier', 
    'security_checker',
    'EnhancedTextProcessor',
    'ModelBenchmark',
    'HackathonPresentation'
]