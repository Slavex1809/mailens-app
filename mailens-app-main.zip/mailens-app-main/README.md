\# 📧 MailLens - Классификатор писем



\## 🚀 Быстрый старт



```bash

docker build -t mailens-app .

docker run -p 8501:8501 mailens-app

